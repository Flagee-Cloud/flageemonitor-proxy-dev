#!/bin/bash

# Definir variáveis de ambiente
export LD_LIBRARY_PATH=/ariusmonitor/libs/32-bits:$LD_LIBRARY_PATH
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games:/usr/local/games:/snap/bin
export XDG_DATA_DIRS=/usr/local/share:/usr/share:/var/lib/snapd/desktop

# Função para verificar o status do serviço no Slackware
check_service_status_slackware() {
    ps aux | grep -v grep | grep -q /etc/rc.d/rc.ariusmonitor
}

# Função para verificar o status do serviço no Ubuntu
check_service_status_ubuntu() {
    if command -v systemctl >/dev/null 2>&1; then
        systemctl is-active --quiet ariusmonitor
    else
        service ariusmonitor status >/dev/null 2>&1
    fi
}

# Parar o serviço se estiver em execução
echo "  * Parando o serviço ariusmonitor se estiver em execução..."
/ariusmonitor/utilities/stop.sh >/dev/null 2>&1

# Detectar distro e iniciar o serviço
if [ -e /etc/slackware-version ] ; then
    echo "  * Iniciando ariusmonitor no Slackware..."
    /etc/rc.d/rc.ariusmonitor start >/dev/null 2>&1

    # Verificar se o serviço foi iniciado com sucesso no Slackware
    if check_service_status_slackware; then
        echo "  * Serviço ariusmonitor iniciado com sucesso no Slackware."
    else
        echo "  * Falha ao iniciar o serviço ariusmonitor no Slackware."
        exit 1
    fi
else
    echo "  * Iniciando ariusmonitor no Ubuntu..."
    if command -v systemctl >/dev/null 2>&1; then
        echo "    * Usando systemctl para iniciar o serviço..."
        systemctl start ariusmonitor >/dev/null 2>&1
        systemctl status ariusmonitor
    else
        echo "    * Usando service/invoke-rc.d para iniciar o serviço..."
        service ariusmonitor start >/dev/null 2>&1
        invoke-rc.d ariusmonitor start >/dev/null 2>&1
        service ariusmonitor status
    fi

    # Verificar se o serviço foi iniciado com sucesso no Ubuntu
    if check_service_status_ubuntu; then
        echo "  * Serviço ariusmonitor iniciado com sucesso no Ubuntu."
    else
        echo "  * Falha ao iniciar o serviço ariusmonitor no Ubuntu."
        exit 1
    fi
fi

# Enviar um sinal para o Zabbix
echo "  * Enviando sinal para o Zabbix..."
/ariusmonitor/zabbix/bin/zabbix_sender -c /ariusmonitor/conf/zabbix_agentd.conf -k ligado -o 1 > /ariusmonitor/logs/zabbix_trapper.log 2>&1

echo "  * Script finalizado com sucesso."
