#!/bin/bash

# Detectar distro
if [ -e /etc/slackware-version ] ; then
	_LINUX_VERSION="SLACKWARE"
else
	_LINUX_VERSION="UBUNTU"
fi


# Removendo customizacao nao utilizada
rm -f /ariusmonitor/conf/zabbix_agentd.conf.d/paguemenos_configs.conf >/dev/null 2>&1
