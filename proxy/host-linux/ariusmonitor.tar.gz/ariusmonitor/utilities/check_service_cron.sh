#!/bin/bash

PATH=/usr/local/sbin:/usr/local/bin:/sbin:/bin:/usr/sbin:/usr/bin

# Usando pgrep para encontrar processos com o nome exato ariusmonitor e contar manualmente
num_processos=$(pgrep -x ariusmonitor | wc -l)

# Debug: Imprime o número de processos
echo "Número de processos ariusmonitor: $num_processos"

# Garante que a variável é tratada como um número
num_processos=$((num_processos + 0))

# Debug: Verifica o valor após a conversão
echo "Valor de num_processos após conversão: $num_processos"

# Compara numericamente o número de processos com 0
if [ "$num_processos" -eq 0 ]; then
    echo "Iniciando o serviço ariusmonitor..."
    /etc/rc.d/rc.ariusmonitor start >/dev/null 2>&1
    service ariusmonitor start >/dev/null 2>&1
    sleep 2
    /ariusmonitor/zabbix/bin/zabbix_sender -c /ariusmonitor/conf/zabbix_agentd.conf -k agent_restart -o 1 > /ariusmonitor/logs/zabbix_trapper.log
else
    echo "O serviço ariusmonitor já está rodando."
fi
