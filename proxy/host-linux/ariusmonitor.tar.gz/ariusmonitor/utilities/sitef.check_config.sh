#!/bin/bash

#EXEMPLO: lyra.supermercadospaguemenos.com.br;gsurf.supermercadospaguemenos.com.br

EnderecoIP=$1
HabilitaMultiplasConexoesSitefUnico=$2

grep -qF "[SiTef]
EnderecoIP=$EnderecoIP
HabilitaMultiplasConexoesSitefUnico=$HabilitaMultiplasConexoesSitefUnico" /posnet/CliSiTef.ini 2>/dev/null && echo 1 || echo 0
