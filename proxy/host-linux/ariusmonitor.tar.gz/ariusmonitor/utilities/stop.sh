#!/bin/bash

# Enviar um sinal para o Zabbix indicando que o serviço está desligando
echo "  * Enviando sinal para o Zabbix indicando desligamento..."
/ariusmonitor/zabbix/bin/zabbix_sender -c /ariusmonitor/conf/zabbix_agentd.conf -k ligado -o 0 > /ariusmonitor/logs/zabbix_trapper.log 2>&1

# Função para verificar se o serviço está parado no Slackware
check_service_stopped_slackware() {
    ! ps aux | grep -v grep | grep -q /etc/rc.d/rc.ariusmonitor
}

# Função para verificar se o serviço está parado no Ubuntu
check_service_stopped_ubuntu() {
    if command -v systemctl >/dev/null 2>&1; then
        ! systemctl is-active --quiet ariusmonitor
    else
        ! service ariusmonitor status >/dev/null 2>&1
    fi
}

# Parar o serviço de acordo com a distribuição
if [ -e /etc/slackware-version ] ; then
    echo "  * Parando o serviço ariusmonitor no Slackware..."
    /etc/rc.d/rc.ariusmonitor stop >/dev/null 2>&1

    # Verificar se o serviço foi parado com sucesso no Slackware
    if check_service_stopped_slackware; then
        echo "  * Serviço ariusmonitor parado com sucesso no Slackware."
    else
        echo "  * Falha ao parar o serviço ariusmonitor no Slackware."
        exit 1
    fi
else
    echo "  * Parando o serviço ariusmonitor no Ubuntu..."
    if command -v systemctl >/dev/null 2>&1; then
        echo "    * Usando systemctl para parar o serviço..."
        systemctl stop ariusmonitor >/dev/null 2>&1
    else
        echo "    * Usando service/invoke-rc.d para parar o serviço..."
        service ariusmonitor stop >/dev/null 2>&1
        invoke-rc.d ariusmonitor stop >/dev/null 2>&1
    fi

    # Verificar se o serviço foi parado com sucesso no Ubuntu
    if check_service_stopped_ubuntu; then
        echo "  * Serviço ariusmonitor parado com sucesso no Ubuntu."
    else
        echo "  * Falha ao parar o serviço ariusmonitor no Ubuntu."
        exit 1
    fi
fi

echo "  * Script de parada finalizado com sucesso."
