\timing
SELECT 1;
