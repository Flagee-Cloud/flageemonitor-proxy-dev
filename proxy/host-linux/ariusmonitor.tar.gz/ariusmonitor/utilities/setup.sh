#!/bin/bash

# Removendo arquivos antigos
echo "  * Removendo arquivos antigos..."
rm -f /ariusmonitor/logs/zabbix_sender.log /etc/cron.d/ariusmonitor >/dev/null 2>&1
rm -f /etc/init/ariusmonitor.conf >/dev/null 2>&1
rm -f /etc/sudoers.d/ariusmonitor >/dev/null 2>&1
systemctl daemon-reload >/dev/null 2>&1

# Criando usuario ariusmonitor se não existir
echo "  * Criando usuarios..."
if ! getent group ariusmonitor >/dev/null; then
    groupadd ariusmonitor >/dev/null 2>&1 || { echo "Erro ao criar grupo ariusmonitor"; exit 1; }
else
    echo "Grupo ariusmonitor já existe."
fi

if ! id -u ariusmonitor >/dev/null 2>&1; then
    useradd ariusmonitor -g ariusmonitor -d /ariusmonitor >/dev/null 2>&1 || { echo "Erro ao criar usuário ariusmonitor"; exit 1; }
else
    echo "Usuário ariusmonitor já existe."
fi
chown -R ariusmonitor. /ariusmonitor

# Detectar distro
if [ -e /etc/slackware-version ] ; then
    _LINUX_VERSION="SLACKWARE"
elif [ -e /etc/lsb-release ] ; then
    _LINUX_VERSION="UBUNTU"
elif [ -e /etc/mint-release ] ; then
    _LINUX_VERSION="MINT"
else
    echo "Distribuição não identificada, ajuste o script conforme necessário."
    exit 1
fi

# Determinar a versão do kernel
_KERNEL_VERSION=$(uname -r | cut -d. -f1,2)

# Mapear a arquitetura correta
_ARCH=$(uname -m)
if [ "$_ARCH" == "x86_64" ]; then
    _ARCH="amd64"
elif [ "$_ARCH" == "i686" ] || [ "$_ARCH" == "i386" ]; then
    _ARCH="i386"
fi

# Escolher a pasta mais próxima com base na versão do kernel
echo "  * Selecionando a pasta do Zabbix Agent..."
case $_KERNEL_VERSION in
    2.6)
        ZABBIX_DIR="zabbix_agent_kernel_2.6-$_ARCH"
        ;;
    3.0)
        ZABBIX_DIR="zabbix_agent_kernel_3.0-$_ARCH"
        ;;
    *)
        # Caso não exista a versão exata, escolha a mais próxima
        if [ "$_KERNEL_VERSION" -lt "3.0" ]; then
            ZABBIX_DIR="zabbix_agent_kernel_2.6-$_ARCH"
        else
            ZABBIX_DIR="zabbix_agent_kernel_3.0-$_ARCH"
        fi
        ;;
esac

# Substituir o link do Zabbix em /ariusmonitor
if [ -d "/ariusmonitor/$ZABBIX_DIR" ]; then
    rm /ariusmonitor/zabbix
    ln -sf "/ariusmonitor/$ZABBIX_DIR" /ariusmonitor/zabbix
    echo "  * Link do Zabbix ajustado para: /ariusmonitor/$ZABBIX_DIR"
else
    echo "Erro: Diretório /ariusmonitor/$ZABBIX_DIR não encontrado."
    exit 1
fi

# Instalar Inits
echo "  * Instalando inits..."
if [ "$_LINUX_VERSION" == "SLACKWARE" ] ; then
    # Slackware-specific setup
    cp /ariusmonitor/utilities/inits/rc.ariusmonitor /etc/rc.d/
    sed -i '/ariusmonitor/d' /etc/rc.d/rc.local
    echo "/etc/rc.d/rc.ariusmonitor start" >> /etc/rc.d/rc.local
    echo "sleep 2" >> /etc/rc.d/rc.local
    echo "/ariusmonitor/zabbix/bin/zabbix_sender -c /ariusmonitor/conf/zabbix_agentd.conf -k ligado -o 1 >/dev/null 2>&1" >> /etc/rc.d/rc.local
else
    # Systemd-based setup (Ubuntu, Mint)
    systemctl disable ariusmonitor >/dev/null 2>&1
    cp /ariusmonitor/utilities/inits/ariusmonitor.service /etc/systemd/system/  >/dev/null 2>&1 || { echo "Erro ao copiar ariusmonitor.service"; exit 1; }
    systemctl daemon-reload >/dev/null 2>&1
    systemctl enable ariusmonitor >/dev/null 2>&1
    cp /ariusmonitor/utilities/inits/ariusmonitor /etc/init.d/ >/dev/null 2>&1 || { echo "Erro ao copiar ariusmonitor para /etc/init.d/"; exit 1; }
    chmod 777 /etc/init.d/ariusmonitor >/dev/null 2>&1
    update-rc.d ariusmonitor defaults >/dev/null 2>&1
fi

# Configurando script de shutdown
echo "  * Configurando script de shutdown..."
cp /ariusmonitor/utilities/inits/ariusmonitor_shutdown /etc/init.d/
chmod +x /etc/init.d/ariusmonitor_shutdown
ln -sf /etc/init.d/ariusmonitor_shutdown /etc/rc0.d/K99ariusmonitor_shutdown
ln -sf /etc/init.d/ariusmonitor_shutdown /etc/rc6.d/K99ariusmonitor_shutdown

# Configuração do cron
echo "  * Configurando cron..."
(crontab -l 2>/dev/null | grep -v 'ariusmonitor'; echo "*/5 * * * * /ariusmonitor/zabbix/bin/zabbix_sender -c /ariusmonitor/conf/zabbix_agentd.conf -k ligado -o 1 > /ariusmonitor/logs/zabbix_trapper.log 2>&1") | crontab -
(crontab -l 2>/dev/null | grep -v 'check_service_cron.sh'; echo "* * * * * /ariusmonitor/utilities/check_service_cron.sh >/dev/null 2>&1") | crontab -

echo "  * Script finalizado com sucesso."
